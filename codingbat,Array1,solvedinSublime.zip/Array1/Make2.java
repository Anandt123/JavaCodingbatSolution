class Make2
{
	public static int[] make2(int[] a, int[] b) 
{
  int []res=new int[2];
  
  if(a.length==0)
  {
    res[0]=b[0];
    res[1]=b[1];
  }
  else if(a.length==1)
  {
    res[0]=a[0];
    res[1]=b[0];
  }
  else
  {
    res[0]=a[0];
    res[1]=a[1];
  }
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={4,5};
	int[]b1={1,2,3};
	System.out.println(make2(a1,b1));
  int[]a2={4};
  int[]b2={1,2,3};
  System.out.println(make2(a2,b2));
  int[]a3={};
  int[]b3={1,2};
  System.out.println(make2(a3,b3));
}
}