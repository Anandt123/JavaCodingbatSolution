class Maxend3
{
	public static int[] maxEnd3(int[] nums) 
	{
		int a=nums[0],b=nums[2];
		if(nums[0] > nums[2])
		{
			nums[2]=nums[1]=a;
		}
		else
		{
			nums[0]=nums[1]=b;
		}
		printArray(nums);
		return nums;
	}

	public static void printArray(int[] a)
	{
		for(int i=0; i<a.length; i++)
		{
			System.out.println(a[i]);
		}
	}

	public static void main(String[] args) 
	{
		int[] a1={1,2,3};
		maxEnd3(a1);
		int[] a2={4,2,6};
		maxEnd3(a2);
	}
}