class Middleway
{
	public static int[] middleWay(int[] a, int[] b) {
  int mid1=(a.length-1)/2;
  int mid2=(b.length-1)/2;
  
  int[] res=new int[2];
  
  res[0]=a[mid1];
  res[1]=b[mid2];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3};
	int[]b1={4,5,6};
	System.out.println(middleWay(a1,b1));
  int[]a2={7,7,7};
  int[]b2={3,8,0};
  System.out.println(middleWay(a2,b2));
  int[]a3={5,2,9};
  int[]b3={1,4,5};
  System.out.println(middleWay(a3,b3));
}
}