class rotateleft3
{
	public static int[] rotateLeft3(int[] nums) {
  int []res=new int[3];
  res[0]=nums[1];
  res[1]=nums[2];
  res[2]=nums[0];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
	for (int i=0; i<a.length; i++) 
	{
		System.out.print(a[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={1,2,3};
	rotateLeft3(a1);
	System.out.println();
	int [] a2={4,0,3};
	rotateLeft3(a2);
}
}