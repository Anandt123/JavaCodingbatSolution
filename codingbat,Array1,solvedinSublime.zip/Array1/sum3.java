class sum3
{
	public static int sum3(int[] nums) {
  return nums[0]+nums[1]+nums[2];
}
public static void main(String[] args) {
	int [] a1={1,2,3};
	System.out.println(sum3(a1));
}
}