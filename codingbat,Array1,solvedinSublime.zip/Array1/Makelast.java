class Makelast
{
	public static int[] makeLast(int[] nums) {
  int[]res=new int[nums.length*2];
  res[res.length-1]=nums[nums.length-1];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={4,5,6};
	System.out.println(makeLast(a1));
  int[]a2={1,2};
  System.out.println(makeLast(a2));
  int[]a3={3};
  System.out.println(makeLast(a3));
}
}