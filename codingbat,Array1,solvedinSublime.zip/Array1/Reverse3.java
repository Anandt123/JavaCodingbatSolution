class Reverse3
{
	public static int[] reverse3(int[] nums) 
	{
		int [] res=new int[3];
		res[0]=nums[2];
		res[1]=nums[1];
		res[2]=nums[0];
		printArray(res);
		return res;
	}
	public static void printArray(int[] a)
	{
		for(int i=0; i<a.length; i++)
		{
			System.out.println(a[i]);
		}
	}
	public static void main(String[] args) 
	{
		int [] nums= {1,2,3};
		reverse3(nums);
		int [] nums1= {15,6,3};
		reverse3(nums1);
	}
}