class Makemiddle
{
	public static int[] makeMiddle(int[] nums) {
  int mid=(nums.length-1)/2;
  int[]res=new int[2];
  
  res[0]=nums[mid];
  res[1]=nums[mid+1];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3,4};
	System.out.println(makeMiddle(a1));
  	int[]a2={7,1,2,3,4,9};
  	System.out.println(makeMiddle(a2));
  	int[]a3={1,2};
  	System.out.println(makeMiddle(a3));
}
}