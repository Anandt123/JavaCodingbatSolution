class Double23
{
	public static boolean double23(int[] nums) {
  if(nums.length==0)
  {
    return false;
  }
  else if(nums.length==1)
  {
    return false;
  }
  else if(nums.length==2&&nums[0]==2&&nums[1]==2)
  {
    return true;
  }
  else if(nums.length==2&&nums[0]==3&&nums[1]==3)
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	int a1[] = {2,2};
	System.out.println(double23(a1));
	int a2[] = {3,3};
	System.out.println(double23(a2));
	int a3[] = {2,3};
	System.out.println(double23(a3));
}
}