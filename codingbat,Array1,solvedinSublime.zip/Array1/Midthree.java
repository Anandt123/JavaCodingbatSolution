class Midthree
{
	public static int[] midThree(int[] nums) 
{
  int mid =(nums.length-1)/2;
  int []res=new int[3];
  
  res[0]=nums[mid-1];
  res[1]=nums[mid];
  res[2]=nums[mid+1];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3,4,5};
	System.out.println(midThree(a1));
  int[]a2={8,6,7,5,3,0,9};
  System.out.println(midThree(a2));
  int[]a3={1,2,3};
  System.out.println(midThree(a3));
}
}