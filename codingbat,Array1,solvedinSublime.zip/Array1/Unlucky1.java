class Unlucky1
{
	public static boolean unlucky1(int[] nums) {
  if (nums.length<2 )
  {
    return false;
  }
  else if(nums[0]==1&&nums[1]==3||nums[1]==1&&nums[2]==3)
  {
    return true;
  }
  else if(nums[nums.length-2]==1&&nums[nums.length-1]==3)
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	int a1[] = {1,2,3,4};
	System.out.println(unlucky1(a1));
	int a2[] = {2,1,3,4,5};
	System.out.println(unlucky1(a2));
	int a3[] = {1,1,1};
	System.out.println(unlucky1(a3));
}
}