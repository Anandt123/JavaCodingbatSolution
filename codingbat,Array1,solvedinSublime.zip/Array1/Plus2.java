class Plus2
{
	public static int[] plusTwo(int[] a, int[] b) {
  int[]res=new int [4];
  
  res[0]=a[0];
  res[1]=a[1];
  res[2]=b[0];
  res[3]=b[1];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2};
	int[]b1={3,4};
	System.out.println(plusTwo(a1,b1));
  int[]a2={4,4};
  int[]b2={2,2};
  System.out.println(plusTwo(a2,b2));
  int[]a3={9,2};
  int[]b3={3,4};
  System.out.println(plusTwo(a3,b3));
}
}