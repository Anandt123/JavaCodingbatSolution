class makepi
{
	public static int[] makePi() {
  int []res=new int[3];
  
  res[0]=3;
  res[1]=1;
  res[2]=4;
  printArray(res);
  return res;
}
public static void printArray(int [] res)
{
	for(int index=0;index<res.length; index++)
	{
		System.out.println(res[index]);
	}
}
public static void main(String[] args) {
	System.out.println(makePi());
}
}