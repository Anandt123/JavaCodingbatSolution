class Fix23
{
	public static int[] fix23(int[] nums) {

  if(nums[0]==2&&nums[1]==3)
  {
    nums[1]=0;
  }
  else if(nums[1]==2&&nums[2]==3)
  {
    nums[2]=0;
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3};
	System.out.println(fix23(a1));
  int[]a2={2,3,5};
  System.out.println(fix23(a2));
  int[]a3={1,2,1};
  System.out.println(fix23(a3));
}
}