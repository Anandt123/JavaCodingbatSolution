class samefirstlast
{
	public static boolean sameFirstLast(int[] nums) {
  if(nums.length==0)
  {
    return false;
  }
  else if(nums[0]==nums[nums.length-1])
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	int [] a1={1,2,3};
	System.out.println(sameFirstLast(a1));
}
}