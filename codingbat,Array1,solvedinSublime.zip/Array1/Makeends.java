class Makeends
{
	public static int[] makeEnds(int[] nums) {
  int[]res=new int[2];
  res[0]=nums[0];
  res[1]=nums[nums.length-1];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3};
	System.out.println(makeEnds(a1));
  int[]a2={1,2,3,4};
  System.out.println(makeEnds(a2));
  int[]a3={7,4,6,2};
  System.out.println(makeEnds(a3));
}
}