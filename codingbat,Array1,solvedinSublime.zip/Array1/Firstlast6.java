class Firstlast6
{
	public static boolean firstLast6(int[] nums) {
  if(nums[0]==6||nums[nums.length-1]==6)
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	int [] a1={1, 2, 6};
	System.out.println(firstLast6(a1));
	int [] a2={6,1, 2, 3};
	System.out.println(firstLast6(a2));
	int [] a3={3,1, 2, 16};
	System.out.println(firstLast6(a3));
}
}