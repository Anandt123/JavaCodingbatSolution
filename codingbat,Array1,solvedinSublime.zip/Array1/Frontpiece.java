class Frontpiece
{
	public static int[] frontPiece(int[] nums) {
  int []res=new int[2];
  if(nums.length<=2)
  {
  	printArray(nums);
    return nums;
  }
  res[0]=nums[0];
  res[1]=nums[1];
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3};
	frontPiece(a1);
	System.out.println();
  	int[]a2={1,2};
  	frontPiece(a2);
  	System.out.println();
  	int[]a3={1};
  	frontPiece(a3);
}
}