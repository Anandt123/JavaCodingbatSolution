class bigger2
{
	public static int[] biggerTwo(int[] a, int[] b) 
	{
  	if(b[0]+b[1]>a[0]+a[1])
  	{
  		printArray(b);
    	return b;
  	}
  	printArray(a);
  	return a;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={3,4};
	int[]b1={1,2};
	System.out.println(biggerTwo(a1,b1));
  int[]a2={3,4};
  int[]b2={4,5};
  System.out.println(biggerTwo(a2,b2));
}
}