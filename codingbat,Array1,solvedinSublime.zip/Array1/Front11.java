class Front11
{
	public static int[] front11(int[] a, int[] b) {
  int []res=new int[2];

  if(a.length==0 && b.length==0)
  {
  	printArray(a);
    return a;
  }
  else if(a.length==0&&b.length>1)
  {
    int [] x = new int[1];
    x[0]=b[0];
    printArray(x);
    return x;
  }
  else if(b.length==0&&a.length>1)
  {
    int []x = new int[1];
    x[0]=a[0];
    printArray(x);
    return x;
  }
  else if(a.length>=1&&b.length>=1)
  {
    int []x = new int[2];
    x[0]=a[0];
    x[1]=b[0];
    printArray(x);
    return x;
  }
  printArray(res);
  return res;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3};
	int[]b1={7,9,8};
	System.out.println(front11(a1,b1));
  int[]a2={1};
  int[]b2={2};
  System.out.println(front11(a2,b2));
  int[]a3={1,7};
  int[]b3={};
  System.out.println(front11(a3,b3));
}
}