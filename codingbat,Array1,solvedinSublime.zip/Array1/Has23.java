class Has23
{
	public static boolean has23(int[] nums) {
  if((nums[0]==2||nums[1]==3)||(nums[0]==3||nums[1]==2))
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	int a1[] = {2,5};
	System.out.println(has23(a1));
	int a2[] = {4,3};
	System.out.println(has23(a2));
	int a3[] = {4,5};
	System.out.println(has23(a3));
}
}