class Swapends
{
	public static int[] swapEnds(int[] nums) 
{
  if(nums.length==1)
  {
    return nums;
  }
  else if(nums.length>1)
  {
    int a=nums[0];
    nums[0]=nums[nums.length-1];
    nums[nums.length-1]=a;
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[] a) 
{
  for (int i=0; i<a.length; i++) 
  {
    System.out.println(a[i]+" ");
  }
}
public static void main(String[] args) {
	int[]a1={1,2,3,4};
	System.out.println(swapEnds(a1));
  int[]a2={1,2,3};
  System.out.println(swapEnds(a2));
  int[]a3={8,6,7,9,5};
  System.out.println(swapEnds(a3));
}
}