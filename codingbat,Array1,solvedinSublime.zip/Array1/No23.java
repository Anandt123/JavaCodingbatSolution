class No23
{
	public static boolean no23(int[] nums) {
  if((nums[0]==2||nums[1]==2)||(nums[0]==3||nums[1]==3))
  {
    return false;
  }
  return true;
}
public static void main(String[] args) {
	int a1[] = {4,5};
	System.out.println(no23(a1));
	int a2[] = {4,2};
	System.out.println(no23(a2));
	int a3[] = {3,5};
	System.out.println(no23(a3));
}
}