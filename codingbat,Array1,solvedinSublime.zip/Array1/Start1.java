class Start1
{
	public static int start1(int[] a, int[] b) 
{
  if(a.length==0 && b.length==0)
  {
    return 0;
  }
  else if((a.length==0&&b[0]==1)||(a[0]==1&&b.length==0))
  {
    return 1;
  }
  else if((a.length==0&&b[0]!=1)||(a[0]!=1&&b.length==0))
  {
    return 0;
  }
  
  else if(a.length>0||b.length>0)
  {
    if(a[0]==1&&b[0]==1)
    {
      return 2;
    }
    else if(a[0]==1||b[0]==1)
    {
      return 1;
    }
    return 0;
  }
  return 1;
}
public static void main(String[] args) {
	int[]a1={1,2,3};
	int[]b1={1,3};
	System.out.println(start1(a1,b1));
  	int[]a2={7,2,3};
  	int[]b2={1};
  	System.out.println(start1(a2,b2));
  	int[]a3={1,2};
  	int[]b3={};
  	System.out.println(start1(a3,b3));
}
}