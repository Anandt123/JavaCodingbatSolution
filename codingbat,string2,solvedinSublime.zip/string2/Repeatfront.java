class Repeatfront
{
	public static String repeatFront(String str, int n)
{
  String s="";
  for(int i=0;i<n;i++)
  {
    s=s+str.substring(0,n-i);
  }
  return s;
}
public static void main(String[] args) {
	System.out.println(repeatFront("Chocolate", 4));
	System.out.println(repeatFront("Chocolate", 3));
	System.out.println(repeatFront("Ice cream", 2));
}
}