class Xybalance
{
	public static boolean xyBalance(String str) 
{
  int j=0;
  int count=0,count1=0;
   for(int i=0;i<str.length();i++)
   {
     if(str.charAt(i)=='x')
     {
       j=i+1;
       count++;
       for(i=j;i<str.length();i++)
        {
          if(str.charAt(i)=='y')
          {
            count1++;
            break;
          }
        }
     }
   }
  
   if(count==count1) return true;
   return false;
}
public static void main(String[] args) {
	System.out.println(xyBalance("aaxbby"));
	System.out.println(xyBalance("aaxbb"));
	System.out.println(xyBalance("yaaxbb"));
}
}