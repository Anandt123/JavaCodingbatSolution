class Endother
{
	public static boolean endOther(String a, String b) 
{
  if(a.length()>=b.length()&&a.substring(a.length()-b.length()).equalsIgnoreCase(b))
  {
    return true;
  }
  else if(b.length()>=a.length()&&b.substring(b.length()-a.length()).equalsIgnoreCase(a))
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	System.out.println(endOther("Hiabc", "abc"));
	System.out.println(endOther("AbC", "HiaBc"));
	System.out.println(endOther("abc", "abXabc"));
}
}