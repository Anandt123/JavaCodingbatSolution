class Prefixagain
{
	public static boolean prefixAgain(String str, int n) 
{
  String s=str.substring(0,n);
  for(int i=1;i<str.length();i++)
  {
    if(i+n<=str.length()&&s.equals(str.substring(i,n+i)))
    {
      return true;
    }
  }
  return false;
}
public static void main(String[] args) {
	System.out.println(prefixAgain("abXYabc", 1));
	System.out.println(prefixAgain("abXYabc", 2));
	System.out.println(prefixAgain("abXYabc", 3));
}
}