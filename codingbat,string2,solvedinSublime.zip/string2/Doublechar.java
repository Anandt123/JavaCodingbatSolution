class Doublechar
{
	public static String doubleChar(String str) {
  String s="";
  for(int i=0;i<str.length();i++)
  {
    s=s+str.substring(i,i+1)+str.substring(i,i+1);
  }
  return s;
}
public static void main(String[] args) {
	System.out.println(doubleChar("The"));
	System.out.println(doubleChar("AAbb"));
	System.out.println(doubleChar("Hi-There"));
}
}