class Samestarchar
{
	public static boolean sameStarChar(String str) 
{
  int count=0;
  int flag=0;
  if(str.length()==0) return true;
  for(int i=1;i<str.length()-1;i++)
  {
    if(str.charAt(i)=='*')
    {
      if(str.charAt(i-1)==str.charAt(i+1))
      {
        count++;
      }
      else
      {
        flag=1;
      }
    }
  }
  if(flag!=1&&count<=str.length()) return true;
  return false;
}
public static void main(String[] args) {
	System.out.println(sameStarChar("xy*yzz"));
	System.out.println(sameStarChar("xy*zzz"));
	System.out.println(sameStarChar("*xa*az"));
}
}