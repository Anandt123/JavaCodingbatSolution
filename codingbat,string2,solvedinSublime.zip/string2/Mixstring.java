class Mixstring
{
	public static String mixString(String a, String b) {
int min = Math.min(a.length(), b.length());

String result = "";
String tail = "";

for(int i = 0; i < min; i++){
result = result + a.charAt(i) + b.charAt(i);
}

if(a.length() < b.length()){
tail = b.substring(min, b.length());
result = result + tail;
}

if(a.length() > b.length()){
tail = a.substring(min, a.length());
result = result + tail;
}
return result;
}
/*
public String mixString(String a, String b) 
{ 
  String s="";
  int l=a.length(),m=b.length();
  int j=0;
  int k=0;
  for(int i=0;i<(l+m);i++)
  {
    if(i-k<=a.length()&&a.length()>=b.length())
    {
      if(i%2==0)
      {
        s=s+a.charAt(k);
        k++;
      }
      if(i%2!=0)
      {
        s=s+b.charAt(j);
        j++;
      }
    }
    else if(i-k>a.length())
    {
      s=s+b.charAt(j);
      j++;
    }
  }
  return s;
}*/
public static void main(String[] args) {
	System.out.println(mixString("abc", "xyz"));
	System.out.println(mixString("Hi", "There"));
	System.out.println(mixString("xxxx", "There"));
}
}