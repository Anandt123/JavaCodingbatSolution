class Xyzmiddle
{
	public static boolean xyzMiddle(String str) 
{
  String str2="", str3="";
  for(int i=0; i<=str.length()-3; i++) 
  {
    while (str.substring(i, i+3).equals("xyz")) 
    {
      str2 = str.substring(0, i);
      str3 = str.substring(i+3);
      if (Math.abs(str2.length()-str3.length())<=1)
      return true;
      break;
    }
  }
  return false;
}
public static void main(String[] args) {
	System.out.println(xyzMiddle("AAxyzBB"));
	System.out.println(xyzMiddle("AxyzBB"));
	System.out.println(xyzMiddle("AxyzBBB"));
}
}