class Repeatseperator
{
	public static String repeatSeparator(String word, String sep, int count)
{
   String s="";
   if(count==0&&sep.length()==0) return "";
   int len = word.length()+sep.length();
   for(int i=0;i<count-1;i++)
   {
     s=s+word+sep;
   }
   return s+word;
}
public static void main(String[] args) {
	System.out.println(repeatSeparator("Word", "X", 3));
	System.out.println(repeatSeparator("This", "And", 2));
	System.out.println(repeatSeparator("This", "And", 3));
}
}