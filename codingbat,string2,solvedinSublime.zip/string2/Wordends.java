class Wordends
{
	public static String wordEnds(String str, String word) 
{
  String s="";
  if(str.length()<=word.length()) return "";
  if(str.substring(0,word.length()).equals(word))
  {
    s=s+str.charAt(word.length());
  }
  for(int i=1;i<str.length()-word.length();i++)
  {
    if(str.substring(i,i+word.length()).equals(word))
    {
      s=s+str.charAt(i-1)+str.charAt(i+word.length());
    }
  }
  if(str.substring(str.length()-word.length()).equals(word))
  {
    s=s+str.charAt(str.length()-word.length()-1);
  }
  return s;
}
public static void main(String[] args) {
	System.out.println(wordEnds("abcXY123XYijk", "XY"));
	System.out.println(wordEnds("XY123XY", "XY"));
	System.out.println(wordEnds("XY1XY", "XY"));
}
}