class Catdog
{
	public static boolean catDog(String str) 
{
  int count=0,count1=0;
  int len=str.length();
  String s="cat",s1="dog";
  if(len<3) return true;
 for(int i=0;i<str.length();i++)
 {
   if(i+3<len&&str.substring(i,i+3).equals(s))
   {
     count++;
   }
   if(i+3<len&&str.substring(i,i+3).equals(s1))
   {
     count1++;
   }
 }
   if(str.substring(len-3).equals(s)) count++;
   if(str.substring(len-3).equals(s1)) count1++;
   if(count==count1) return true;
   return false;
}
public static void main(String[] args) {
	System.out.println(catDog("catdog"));
	System.out.println(catDog("catcat"));
	System.out.println(catDog("1cat1cadodog"));
}
}