class Xyzthere
{
	public static boolean xyzThere(String str) 
{
  String s="xyz",s1=".";
  if(str.length()<3) return false;
  if(str.length()==3&&str.equals(s)) return true;
  if(str.charAt(str.length()-4)!='.'&&str.substring(str.length()-3).equals(s))
  return true;
  if(str.length()>8&&str.charAt(str.length()-4)=='.') return false;
  for(int i=0;i<str.length();i++)
  {
    if(i+3<str.length()&&str.substring(i,i+3).equals(s))
    {
      return true;
    }
  }
  return false;
}
public static void main(String[] args) {
	System.out.println(xyzThere("abcxyz"));
	System.out.println(xyzThere("abc.xyz"));
	System.out.println(xyzThere("xyz.abc"));
}
}