class Plusout
{
	/*public String plusOut(String str, String word) {

String result = "";

int sl = str.length();
int wl = word.length();

int pos = 0;

for(int i = pos; i <= sl - wl; i++){
if(str.substring(i, i + wl).equals(word)){
result += word;
i += wl - 1;
pos += word.length();
} else {
result += "+";
pos++;
}
}

for(int i = pos; i < str.length(); i++){
result += "+";
}

return result;

}
*/

public static String plusOut(String str, String word) 
{
  String s="";
  int pos=0;
  for(int i=pos;i<=str.length()-word.length();i++)
  {
    if(str.substring(i,i+word.length()).equals(word))
    {
      s=s+word;
      i=i+word.length()-1;
      pos+=word.length();
    }
    else
    {
      s=s+'+';
      pos++;
    }
  }
  for(int i=pos;i<str.length();i++)
  {
    s+="+";
  }
  return s;
}
public static void main(String[] args) 
{
	System.out.println(plusOut("12xy34", "xy"));
	System.out.println(plusOut("12xy34", "1"));
	System.out.println(plusOut("12xy34xyabcxy", "xy"));
}
}