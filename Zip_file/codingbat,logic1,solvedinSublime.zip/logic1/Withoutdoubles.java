class Withoutdoubles
{
	public static int withoutDoubles(int die1, int die2, boolean noDoubles) 
{
  int sum;
  sum=die1+die2;
  if((die1==6&&die2==6)&&(noDoubles==true))
  {
    return 7;
  }
  else if(noDoubles==true)
  {
    if((die1==die2)&&(die1<=6&&die1>=1)&&(die2<=6&&die2>=1))
    {
      return sum+1;
    }
    return sum;
  }
  
  return sum;
}
public static void main(String[] args) {
	System.out.println(withoutDoubles(2, 3, true));
	System.out.println(withoutDoubles(3, 3, true));
	System.out.println(withoutDoubles(3, 3, false));
}
}