class Greenticket
{
	public static int greenTicket(int a, int b, int c) 
{
  if(a!=b&&b!=c&&c!=a)
  {
    return 0;
  }
  else if(a==b&&b==c&&c==a)
  {
    return 20;
  }
  else if((a==b&&b!=c)||(b==c&&c!=a)||(c==a&&c!=b))
  {
    return 10;
  }
  return 0;
}
public static void main(String[] args) {
	System.out.println(greenTicket(1,2,3));
	System.out.println(greenTicket(2,2,2));
	System.out.println(greenTicket(1,1,2));
}
}