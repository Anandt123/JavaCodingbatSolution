class Sumlimit
{
	public static int sumLimit(int a, int b) 
{
  int c=a+b;
  String a1=String.valueOf(a);
  String b1=String.valueOf(b);
  String s1=String.valueOf(c);
  
  if(a1.length()==s1.length())
  {
    return c;
  }
  return a;
}
public static void main(String[] args) {
	System.out.println(sumLimit(2,3));
	System.out.println(sumLimit(8,3));
	System.out.println(sumLimit(8,1));
}
}