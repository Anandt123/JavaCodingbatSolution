class Teensum
{
	public static int teenSum(int a, int b) 
{
  int sum;
  sum=a+b;
  if((a<=19&&a>=13)||(b<=19&&b>=13))
  {
    return 19;
  }
  return sum;
}
public static void main(String[] args) {
	System.out.println(teenSum(3,4));
		System.out.println(teenSum(10,13));
		System.out.println(teenSum(13,2));
}
}