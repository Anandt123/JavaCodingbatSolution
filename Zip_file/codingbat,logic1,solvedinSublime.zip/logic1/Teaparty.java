class Teaparty
{
	public static int teaParty(int tea, int candy) 
{
  if((tea>=candy*2&&candy>=5)||(candy>=tea*2&&tea>=5))
  {
    return 2;
  }
  
  else if (tea>=5&&candy>=5)
  {
    return 1;
  }
  else if(tea<5||candy<5)
  {
    return 0;
  }
  
  return 0;
}
public static void main(String[] args) {
	System.out.println(teaParty(6,8));
		System.out.println(teaParty(3,8));
		System.out.println(teaParty(20,6));
}
}