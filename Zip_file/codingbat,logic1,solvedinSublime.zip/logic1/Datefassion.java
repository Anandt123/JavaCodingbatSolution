class Datefassion
{
	public static int datefassion(int you, int date)
	{
		if((you>=8&&date>2)||(date>=8&&you>2))
		{
			return 2;
		}
		else if(date<=2||you<=2)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	public static void main(String[] args) {
		System.out.println(datefassion(5,10));
		System.out.println(datefassion(10,2));
		System.out.println(datefassion(5,5));

	}
}