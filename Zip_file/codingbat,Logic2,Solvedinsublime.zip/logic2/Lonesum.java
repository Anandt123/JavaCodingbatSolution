class Lonesum
{
	public static int loneSum(int a, int b, int c) {
  if(a==b&&b==c&&c==a)
  {
    return 0;
  }
  else if(a==b)
  {
    return c;
  }
  else if(b==c)
  {
    return a;
  }
  else if(c==a)
  {
    return b;
  }
  return a+b+c;
}
public static void main(String[] args) {
	System.out.println(loneSum(1,2,3));
	System.out.println(loneSum(3,2,3));
	System.out.println(loneSum(3,3,3));
}
}