class Luckysum
{
	public static int luckySum(int a, int b, int c) {
  if(a!=13&&b!=13&&c!=13)
  {
    return a+b+c;
  }
  else if(a!=13&&b!=13&&c==13)
  {
    return a+b;
  }
  else if(a!=13&&b==13)
  {
    return a;
  }
  else if(a==13)
  {
    return 0;
  }
  return 0;
}
public static void main(String[] args) {
	System.out.println(luckySum(1,2,3));
	System.out.println(luckySum(1,2,13));
	System.out.println(luckySum(1,13,3));
}
}