class Noteensum
{
	public static int noTeenSum(int a, int b, int c) 
{
  int x=fixTeen(a);
  int y=fixTeen(b);
  int z=fixTeen(c);
  return x+y+z;
}
public static int fixTeen(int n)
{
  if(n==15||n==16||n<13||n>19)
  {
    return n;
  }
  return 0;
}
public static void main(String[] args) {
	System.out.println(noTeenSum(1, 2, 3));
	System.out.println(noTeenSum(2, 13, 1));
	System.out.println(noTeenSum(2, 1, 14));
}
}