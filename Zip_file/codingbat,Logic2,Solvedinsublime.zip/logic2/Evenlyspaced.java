class Evenlyspaced
{
	public static boolean evenlySpaced(int a, int b, int c) 
{
  if(a-b==b-c || b-c==c-a || c-a==a-b )
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	System.out.println(evenlySpaced(2, 4, 6));
	System.out.println(evenlySpaced(4, 6, 2));
	System.out.println(evenlySpaced(4, 6, 3));
}
}