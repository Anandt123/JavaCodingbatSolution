class Roundsum
{
	public static int roundSum(int a, int b, int c) 
{
  int x=round10(a);
  int y=round10(b);
  int z=round10(c);
  return x+y+z;
}
public static int round10(int nums)
{
  if(nums%10>=5)
  {
    return ((nums/10)*10)+10;
  }
  else if(nums%10<5)
  {
    return ((nums/10)*10);
  }
  return nums;
}
public static void main(String[] args) {
	System.out.println(roundSum(16, 17, 18));
	System.out.println(roundSum(12, 13, 14));
	System.out.println(roundSum(6, 4, 4));
}
}