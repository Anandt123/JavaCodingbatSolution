class Blackjack
{
	public static int blackjack(int a, int b) {
  if(a<22&&b<22)
  {
    if(Math.abs(a-21)<Math.abs(b-21))
    {
      return a;
    }
    return b;
  }
  if(a<22&&b>21)
  {
    return a;
  }
  else if(a>21&&b<22)
  {
    return b;
  }
  return 0;
}
public static void main(String[] args) {
	System.out.println(blackjack(19, 21));
	System.out.println(blackjack(21, 19));
	System.out.println(blackjack(19, 22));
}
}