class maxspan
{
	public static int maxSpan(int[] nums) 
{
  int temp=0;
  int span=0;
  for(int i=0;i<nums.length;i++)
  {
    for(int j=0;j<nums.length;j++)
    {
      if(nums[i]==nums[j])
      {
        temp=j-i+1;
      }
    }
    if(temp>span)
    {
      span=temp;
    }
  }
  return span;
}
public static void main(String[] args) {
	int [] a1 = {1,2,1,1,3};
	System.out.println(maxSpan(a1));
}
}