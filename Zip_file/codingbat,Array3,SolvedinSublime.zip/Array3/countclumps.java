class countclumps
{
	public static int countClumps(int[] nums) {
   boolean match = false;
  int count = 0;
  for (int i = 0; i < nums.length-1; i++) 
  {
    if (nums[i] == nums[i+1] && !match) 
    {
      match = true;
      count++;
    }
    else if (nums[i] != nums[i+1]) 
    {
      match = false;
    }
  }
  return count;
}
public static void main(String[] args) {
	int [] a1={1,2,2,3,4,4};
	System.out.println(countClumps(a1));
}
}