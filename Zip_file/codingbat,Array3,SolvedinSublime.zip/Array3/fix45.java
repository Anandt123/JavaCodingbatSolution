class fix45
{
	public static int[] fix45(int[] nums) {
  int t=0;
  for(int i=0;i<nums.length;i++)
  {
    for(int j=0;j<nums.length;j++)
    {
      if(nums[i]==5&&nums[j]==4)
      {
        t=nums[j+1];
        nums[j+1]=nums[i];
        nums[i]=t;
      }
    }
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[] nums) 
{
	for (int i=0; i<nums.length; i++) 
	{
		System.out.print(nums[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={5,4,9,4,9,5};
	System.out.println(fix45(a1));
}
}