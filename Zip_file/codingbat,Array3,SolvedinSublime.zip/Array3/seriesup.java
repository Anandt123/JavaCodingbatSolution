class seriesup
{
	public static int[] seriesUp(int n) {
  int[]res=new int[n*(n+1)/2];
  int index=0;
  for(int i=1;i<=n;i++)
  {
    for(int j=1;j<=i;j++)
    {
      res[index]=j;
      index++;
    }
  }
  printArray(res);
  return res;
}
public static void printArray(int[] res) 
{
  for (int i=0; i<res.length; i++) 
  {
    System.out.print(res[i]+" ");
  }
}
public static void main(String[] args) {
	System.out.println(seriesUp(3));
}
}