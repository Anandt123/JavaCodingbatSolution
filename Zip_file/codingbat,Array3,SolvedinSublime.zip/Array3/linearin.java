class linearin
{
  public static boolean linearIn(int[] outer, int[] inner) {
  int count=0;
  int flag=0;
  if(inner.length>0)
  {
    for(int i=0;i<inner.length;i++)
    { 
     flag=0;
      for(int j=0;j<outer.length;j++)
      { 
         if(inner[i]==outer[j])
         {
           flag=1;
            count++;
          }
       }
    }
  }
  if(count>=inner.length&&flag==1||inner.length==0)
    {
     return true;
    }
    return false;
}

public static void main(String[] args) {
  int [] a1={1,2,4,6};
  int [] b1={2,4};
  System.out.println(linearIn(a1,b1));
}
}