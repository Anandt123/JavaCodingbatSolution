class fix34
{
  public static int[] fix34(int[] nums) {
   int t=0;
  for(int i=0; i< nums.length ; i++)
  {
    for(int j=0;j<nums.length ; j++)
    {
      if(nums[i]==4 && nums[j]==3)
       {
          t=nums[j+1];
          nums[j+1]=nums[i];
          nums[i]=t;
        }
    }
  }

  printArray(nums);
  return nums;
}
public static void printArray(int[] nums) 
{
  for (int i=0; i<nums.length; i++) 
  {
    System.out.print(nums[i]+" ");
  }
}
public static void main(String[] args) {
  int [] a1={1,3,1,4};
  System.out.println(fix34(a1));
}
}