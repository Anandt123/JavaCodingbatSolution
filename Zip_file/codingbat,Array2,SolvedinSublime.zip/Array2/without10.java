class without10
{
	public static int[] withoutTen(int[] nums) {
   int[] tab = new int[nums.length];
  int counter = 0;
  for (int i = 0; i < nums.length; i++)
  {
    if (nums[i] != 10)
    tab[counter++] = nums[i];
  }
  printArray(tab);
  return tab;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={1,10,10,2};
	System.out.println(withoutTen(a1));
}
}

