class lucky13
{
	public static boolean lucky13(int[] nums) 
{
  boolean flag=true;
  for(int i=0;i<nums.length;i++)
  {
    if((nums[i]==1)||(nums[i]==3))
    {
      flag=false;
    }
  }
  return flag;
}
public static void main(String[] args) {
	int [] a1={0,2,4};
	System.out.println(lucky13(a1));
}
}