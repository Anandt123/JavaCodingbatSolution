class tenrun
{
	public static int[] tenRun(int[] nums) {
  int multiple = -1;
  for(int i = 0; i < nums.length; i++) 
  {
    if(multiple != -1 && nums[i]%10 != 0) nums[i] = multiple;
    if(nums[i]%10 == 0) multiple = nums[i];
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int []a1={2,10,3,4,20,5};
	System.out.println(tenRun(a1));
}
}