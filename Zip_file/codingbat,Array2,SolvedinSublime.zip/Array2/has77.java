class has77
{
	public static boolean has77(int[] nums) {
  boolean a=false;
  
  for(int i=0;i<nums.length-2;i++)
  {
    if(nums[i]==7&&nums[i+1]==7)
    {
      a=true;
    }
    if((nums[nums.length-1]==7&&nums[nums.length-2]==7)||(nums[i]==7&&nums[i+2]==7))
    {
      a=true;
    }
  }
  return a;
}
public static void main(String[] args) {
	int [] a1={1,7,7};
	System.out.println(has77(a1));
}
}