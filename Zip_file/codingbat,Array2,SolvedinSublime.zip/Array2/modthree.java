class modthree
{
	public static boolean modThree(int[] nums) {
  boolean flag=false;
  for(int i=0;i<nums.length-2;i++)
  {
    if((nums[i]%2==0&&nums[i+1]%2==0&&nums[i+2]%2==0)||(nums[i]%2!=0&&nums[i+1]%2!=0&&nums[i+2]%2!=0))
    {
      flag=true;
    }
  }
  return flag;
}
public static void main(String[] args) {
	int [] a1={2,1,3,5};
	System.out.println(modThree(a1));
}
}