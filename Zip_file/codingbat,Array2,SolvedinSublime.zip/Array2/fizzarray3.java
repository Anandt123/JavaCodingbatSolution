class fizzarray3
{
	public static int[] fizzArray3(int start, int end) 
{
  int [] fizzarray=new int[end-start];
  for(int i=0; i<end-start; i++)
  {
    fizzarray[i]=start+i;
  }
  printArray(fizzarray);
  return fizzarray;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	System.out.println(fizzArray3 (5,10));
	System.out.println(fizzArray3 (11,18));
}
}