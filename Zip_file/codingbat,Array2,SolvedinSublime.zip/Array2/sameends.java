class sameends
{
	public static boolean sameEnds(int[] nums, int len) 
{
  int count =0;
  int j=nums.length-len;
  if(len<=nums.length)
  {
    for(int i=0;i<len;i++)
    {
      if(nums[i]==nums[j])
      {
        j++;
        count++;
      }
    }
    if(count==len)
    {
      return true;
    }
    return false;
  }
  return false;
}
public static void main(String[] args) {
	int[]a1={5, 6, 45, 99, 13, 5, 6};
	System.out.println(sameEnds(a1,1));
}
}