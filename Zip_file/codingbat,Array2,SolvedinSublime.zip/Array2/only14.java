class only14
{
	public static boolean only14(int[] nums) {
  boolean a=true;
  for(int i=0;i<nums.length;i++)
  {
    if(nums[i]!=1&&nums[i]!=4)
    {
      a=false;
    }
  }
  return a;
}
public static void main(String[] args) {
	int [] a1={1,4,1,4};
	System.out.println(only14(a1));
}
}