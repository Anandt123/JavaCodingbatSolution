class sum67
{
	public static int sum67(int[] nums) {
  int s = 0;
  boolean stop = false;
  for (int i = 0; i < nums.length; i++) 
  {
    if (nums[i] == 6)
    {
      stop = true;
    }
    else if (stop == false)
    {
      s =s+ nums[i];
    }
    else if (nums[i] == 7 && stop == true)
    {
      stop = false;
    }
  }
  return s;
}
public static void main(String[] args) {
	int [] a1 = {1, 2, 2, 6, 99, 99, 7};
	System.out.println(sum67(a1));
}
}