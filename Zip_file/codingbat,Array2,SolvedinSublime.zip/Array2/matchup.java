class matchup
{
	public static int matchUp(int[] nums1, int[] nums2) 
{
  int count=0;
  for(int i=0;i<nums1.length; i++)
  {
    if(nums1[i]>nums2[i]-3&&nums1[i]<nums2[i]+3&&nums1[i]!=nums2[i])
    {
      count++;
    }
  }
  return count;
}
public static void main(String[] args) {
	int [] a1={1,2,3};
	int [] b1={2,3,10};
	System.out.println(matchUp(a1,b1));
}
}