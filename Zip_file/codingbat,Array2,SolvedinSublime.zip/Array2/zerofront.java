class zerofront
{
	public static int[] zeroFront(int[] nums) {
   int nums2[] = new int[nums.length];
  int count = 0;

  for (int i = nums.length - 1; i >= 0; i--)
  {
  if (nums[i] != 0)
    {
      nums2[i + count] = nums[i];
    }
    else
    {
      count++;
    }
  }
  printArray(nums2);
  return nums2;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={1,0,0,1};
	System.out.println(zeroFront(a1));
}
}