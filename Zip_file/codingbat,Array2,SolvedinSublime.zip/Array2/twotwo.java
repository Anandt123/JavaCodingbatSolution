class twotwo
{
	public static boolean twoTwo(int[] nums) 
{
  if(nums.length==0)
  {
    return true;
  }
  if(nums.length==1&&nums[0]==2)
  {
    return false;
  }
  if(nums[nums.length-1]==2&&nums[nums.length-2]!=2)
  {
    return false;
  }
  for(int i=1;i<nums.length-1;i++)
  {
    if(nums[i]==2)
    {
      if(nums[i-1]!=2&&nums[i+1]!=2)
      {
        return false;
      }
    }
  }
  return true;
}
public static void main(String[] args) {
	int[] a1={4,2,2,3};
	System.out.println(twoTwo(a1));
}
}