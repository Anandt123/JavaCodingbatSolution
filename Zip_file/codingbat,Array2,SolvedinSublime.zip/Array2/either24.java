class either24
{
	public static boolean either24(int[] nums) 
{
  boolean a=false;
  boolean b=false;
  for(int i=0;i<nums.length-1;i++)
  {
    
    if(nums[i]==2&&nums[i+1]==2)
    {
      a= true;
    }
    if(nums[i]==4&&nums[i+1]==4)
    {
      b= true;
    }
  }
    if(a&&b)
    {
      return false;
    }
    else if(!a&&!b)
    {
      return false;
    }
  return true;
}
public static void main(String[] args) {
	int [] a1={1,2,2};
	System.out.println(either24(a1));
}
}