class fizzarray
{
	public static int[] fizzArray(int n) 
{
  int []res=new int[n];
  int x=0;
  for(int i=0;i<n;i++)
  {
    res[i]=x;
    x++;
  }
  printArray(res);
  return res;
}
public static void printArray(int [] res)
{
	for(int index=0;index<res.length; index++)
	{
		System.out.print(res[index]+" ");
	}
}
public static void main(String[] args) {
	System.out.println(fizzArray(3));
}
}