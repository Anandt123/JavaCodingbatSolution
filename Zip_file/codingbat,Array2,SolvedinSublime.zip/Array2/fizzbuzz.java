class fizzbuzz
{
	public static String[] fizzBuzz(int start, int end) {
  String[] fizzB = new String[end-start];
    for (int i = start, j=0; i < end; i++, j++) 
    {
      fizzB[j] = String.valueOf(i);
      if (i % 3 == 0 && i % 5 == 0) 
      {
          fizzB[j] = "FizzBuzz";
      }
      else if (i % 3 == 0) 
      {
        fizzB[j] = "Fizz";
      }
      else if (i % 5 == 0) 
      {
        fizzB[j] = "Buzz";
      }
    }
    printArray(fizzB);
  return fizzB;
}
public static void printArray(String[] nums)
{
	for(int i=0;i<nums.length; i++)
	{
		System.out.println(nums[i]);
	}
}
public static void main(String[] args) {
	System.out.println(fizzBuzz(1,6));
}
}