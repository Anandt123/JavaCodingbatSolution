class fizzarray2
{
	public static String[] fizzArray2(int n) {
  String[] fizz=new String[n];
  int c=0;
  for(int i=0; i<n; i++)
  {
    fizz[i]=Integer.toString(c++);
  }
  printArray(fizz);
  return fizz;
}
public static String[] printArray(int [] res)
{
	for(int index=0;index<res.length(); index++)
	{
		fizz[index]=Integer.toString(index);
		System.out.print(res[index]);
	}
}
public static void main(String[] args) {
	System.out.println(fizzArray2(4));
}
}