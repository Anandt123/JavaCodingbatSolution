class countevens
{
	public static int countEvens(int[] nums) {
  int count=0;
  for (int i=0;i<nums.length; i++)
  {
    if(nums[i]%2==0)
    {
      count++;
    }
  }
  return count;
}
public static void main(String[] args) {
	int [] a1= {2,1,2,3,4};
	System.out.println(countEvens(a1));
}
}