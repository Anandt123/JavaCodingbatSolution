class shiftleft
{
	public static int[] shiftLeft(int[] nums) {
   int[] c=new int[nums.length]; 
  if(nums.length>0)
  {
    c[nums.length-1]=nums[0];
    for(int i=1;i<nums.length;i++)
    {
     c[i-1]=nums[i];
    }
    printArray(c);
    return c;
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1 ={6,2,5,3};
	System.out.println(shiftLeft(a1));
}
}