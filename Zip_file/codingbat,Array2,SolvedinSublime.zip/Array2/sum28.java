class sum28
{
	public static boolean sum28(int[] nums) 
{
  int a=0;
  boolean x = false;
  for(int i=0;i<nums.length;i++)
  {
    if(nums[i]==2)
    {
      a=a+2;
    }
    if(a == 8)
    {
      x=true;
    }
    else
    {
       x=false;
    }
  }
  return x;
}
public static void main(String[] args) {
	int [] a1={2,3,2,2,4,2};
	System.out.println(sum28(a1));
}
}