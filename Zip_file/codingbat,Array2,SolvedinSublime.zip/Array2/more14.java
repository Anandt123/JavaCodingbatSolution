class more14
{
	public static boolean more14(int[] nums) 
{
  int count1=0;
  int count2=0;
  for(int i=0;i<nums.length;i++)
  {
    if(nums[i]==1)
    {
      count1++;
    }
    if(nums[i]==4)
    {
      count2++;
    }
  }
  if(count1>count2)
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	int [] a1 = {1,4,1};
	System.out.println(more14(a1));
}
}