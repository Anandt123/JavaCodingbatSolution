class evenodd
{
	public static int[] evenOdd(int[] nums) {
    int len = nums.length;
  int temp = 0;
  int pos = 0;

  for (int i = 0; i < nums.length; i++)
  {
   if (nums[i] % 2 == 0) 
   {
      temp = nums[pos];
      nums[pos] = nums[i];
      nums[i] = temp;
      pos++;
    }
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int []a1={1,0,1,0,0,1,1};
	System.out.println(evenOdd(a1));
}
}
