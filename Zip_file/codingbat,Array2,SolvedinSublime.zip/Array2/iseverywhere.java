class iseverywhere
{
	public static boolean isEverywhere(int[] nums, int val) 
{
  boolean marker=false;
  int k=0;
  int m=0;
  if(nums.length<2)
  {
    return true;
  }
  if(val==nums[0])
  {
    for(int i=0;i<nums.length;i=i+2)
    {
      if(nums[i]==val)
      {
        marker=true;
      }
      else
      {
        marker=false;
        k=1;
      }
    }
  }
  if(val==nums[1])
  {
    for(int i=1;i<nums.length;i=i+2)
    {
      if(nums[i]==val)
      {
        marker=true;
      }
      else
      {
        marker=false;
        m=1;
      }
    }
  }
  if(k==1||m==1)
  {
    return false;
  }
  return marker;
}
public static void main(String[] args) {
	int [] a1={1,2,1,3};
	
	System.out.println(isEverywhere(a1,1));
}
}