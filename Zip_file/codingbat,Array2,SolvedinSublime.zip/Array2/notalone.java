class notalone
{
	public static int[] notAlone(int[] nums, int val) {
   for(int i=1;i<nums.length-1;i++)
  {
    if(nums[i]!=nums[i+1]&&nums[i]!=nums[i-1])
    {
      if(nums[i-1]>nums[i+1])
      {
        nums[i]=nums[i-1];
      }
      if(nums[i+1]>nums[i-1])
      {
        nums[i]=nums[i+1];
      }
    }
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={1,2,3};
	System.out.println(notAlone(a1,2));
}
}
