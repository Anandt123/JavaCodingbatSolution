class has12
{
	public static boolean has12(int[] nums) {
  boolean a=false;
  boolean b=false;
  for(int i=0;i<nums.length;i++)
  {
    if(nums[i]==1)
    {
      a=true;
    }
    if(a&&nums[i]==2)
    {
      b=true;
    }
  }
  return b;
}
public static void main(String[] args) {
	int []a1={1,3,2};
	System.out.println(has12(a1));
}
}