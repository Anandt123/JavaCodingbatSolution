class centredavrg
{
	public static int smallest(int[] nums) 
{
  int small=nums[0];
  for(int i=1;i<nums.length;i++)
  {
    if(nums[i]<small)
    {
      small=nums[i];
    }
  }
  return small;
}

public static int largest(int[] nums) 
{
  int large=nums[0];
  for(int i=1;i<nums.length;i++)
  {
    if(nums[i]>large)
    {
      large=nums[i];
    }
  }
  return large;
}

public static int centeredAverage(int[] nums) 
{
  int large=largest(nums);
  int small=smallest(nums);
  int sum=0;
  for(int i=0;i<nums.length;i++)
  {
    sum=sum+nums[i];
  }
  sum=sum-large-small;
  sum=sum/(nums.length-2);
  return sum;
}
public static void main(String[] args) {
	int [] a1={1, 2, 3, 4, 100};
	System.out.println(centeredAverage(a1));
}

}