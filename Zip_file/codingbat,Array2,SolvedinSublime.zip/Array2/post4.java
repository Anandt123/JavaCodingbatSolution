class post4
{
	public static int[] post4(int[] nums) {
   int j=1;
  int k=1;
  for(int i=0;i<nums.length;i++)
  {
    if(nums[i]==4)
    {
      j=i+1;
      k=j;
    }
  }
  int[] c=new int[nums.length-j];
  for(int count=0;count<nums.length-j;count++)
  {
    c[count]=nums[k];
    k++;
    
  }
  printArray(c);
  return c;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={2,4,1,2};
	System.out.println(post4(a1));
}
}