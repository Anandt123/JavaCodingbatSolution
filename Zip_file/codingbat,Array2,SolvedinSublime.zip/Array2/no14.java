class no14
{
	public static boolean no14(int[] nums) 
{
  int marker=0;
  int marker1=0;
  for(int index=0; index<nums.length; index++)
  {
    if(nums[index]==1)
    {
      marker=1;
    }
    if(nums[index]==4)
    {
      marker1=1;
    }
  }
  if(marker==1&&marker1==1)
  {
    return false;
  }
  return true;
}
public static void main(String[] args) {
	int [] a1 = {1,2,3,4};
	System.out.println(no14(a1));
}
}