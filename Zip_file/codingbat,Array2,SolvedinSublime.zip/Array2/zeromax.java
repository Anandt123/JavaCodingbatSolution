class zeromax
{
	public static int[] zeroMax(int[] nums) {
   int max=0;
  for (int i=0; i<nums.length; i++) 
  {
    if (nums[i]==0)   
    {
      for (int j=i+1; j<nums.length; j++) 
      {
        if (nums[j]%2==1) 
        {
          max = Math.max(max,nums[j]);
        }
      }
      nums[i]=max;
      //need reset max here.
      max=0;
    }
  }
  printArray(nums);
  return nums;
}
public static void printArray(int[]res)
{
	for (int i=0; i<res.length; i++) 
	{
		System.out.print(res[i]+" ");
	}
}
public static void main(String[] args) {
	int [] a1={0,5,0,3};
	System.out.println(zeroMax(a1));
}
}