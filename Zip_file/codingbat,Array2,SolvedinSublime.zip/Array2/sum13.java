class sum13
{
	public static int sum13(int[] nums) 
{
  int sum=0;
  for (int i=0;i<nums.length;i++)
  {
    if(nums[i]==13&&i<nums.length-1)
    {
      nums[i]=0;
      nums[i+1]=0;
      sum = sum+nums[i];
    }
    else if(nums[i]!=13)
    {
      sum=sum+nums[i];
    }
  }
  return sum;
}
public static void main(String[] args) {
	int [] a1={1,2,2,1};
	System.out.println(sum13(a1));
}
}