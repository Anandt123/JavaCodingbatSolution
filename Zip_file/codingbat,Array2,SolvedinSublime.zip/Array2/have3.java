class have3
{
	public static boolean haveThree(int[] nums) {
  int count=0;
  for(int i=0;i<nums.length;i++)
  {
    if(nums[i]==3&&i+2<nums.length&&nums[i+2]==3)
    {
      count++;
    }
  }
  if(count==2)
    {
      return true;
    }
  return false;
}
public static void main(String[] args) {
	int[] a1 ={3,1,3,3};
	System.out.println(haveThree(a1));
}
}