class Extrafront
{
	public static String extraFront(String str) {
  if(str.length()>=2)
  {
    str=str.substring(0,2);
  }
  return str+str+str;
}
public static void main(String[] args) {
	System.out.println(extraFront("Hello"));
	System.out.println(extraFront("AK"));
}
}