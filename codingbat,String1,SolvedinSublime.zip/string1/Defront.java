class Defront
{
	public static String deFront(String str) {    
  if(str.length()==0&&str.charAt(0)!='a')
  {
    return "";
  }
  if(str.length()>=2)
  {
    
    if(str.charAt(0)!='a'&&str.charAt(1)!='b')
    {
      return str.substring(2);
    }
    if(str.charAt(0)=='a'&&str.charAt(1)=='b')
    {
      return str.substring(0);
    }
    else if(str.charAt(0)!='a')
    {
      return str.substring(1);
    }
    else if(str.charAt(0)!='b')
    {
      return 'a'+ str.substring(2);
    }
  }
  return str;
}
public static void main(String[] args) {
	System.out.println(deFront("Hello"));
	System.out.println(deFront("java"));
	System.out.println(deFront("away"));
}
}