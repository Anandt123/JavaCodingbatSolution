class Endsly
{
	public static boolean endsLy(String str) 
{
  int a=str.length();
  String ly="ly";
  
  if(a<2)
  {
    return false;
  }
  else if(a>=2&&(ly.equals(str.substring(a-2,a))))
  {
    return true;
  }
  return false;
}
public static void main(String[] args) {
	System.out.println(endsLy("oddly"));
	System.out.println(endsLy("anand"));
}
}