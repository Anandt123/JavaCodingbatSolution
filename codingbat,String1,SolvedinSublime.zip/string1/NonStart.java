class NonStart
{
	public static String nonStart(String a, String b) {
   String res=a.substring(1,a.length())+b.substring(1,b.length());
   return res;
}
public static void main(String[] args) {
	System.out.println(nonStart("Hello", "There"));
	System.out.println(nonStart("anand", "kumar"));
}
}