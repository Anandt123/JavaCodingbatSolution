class Lasttwo
{
	public static String lastTwo(String str) {
  if(str.length()==0)
  {
    return "";
  }
  if(str.length()==1)
  {
    return str;
  }
  char a=str.charAt(str.length()-1);
  char b=str.charAt(str.length()-2);
  String c=str.substring(0,str.length()-2);
  return c+a+b;
}
public static void main(String[] args) {
	System.out.println(lastTwo("coding"));
	System.out.println(lastTwo("cat"));
	System.out.println(lastTwo("ab"));
}
}