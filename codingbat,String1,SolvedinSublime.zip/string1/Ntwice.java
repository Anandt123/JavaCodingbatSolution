class Ntwice
{
	public static String nTwice(String str, int n) {
  return str.substring(0,n)+str.substring(str.length()-n,str.length());
}
public static void main(String[] args) {
	System.out.println(nTwice("Hello", 2));
	System.out.println(nTwice("chocolate", 3));
}
}