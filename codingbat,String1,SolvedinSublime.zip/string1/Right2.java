class Right2
{
	public static String right2(String str) {
  String a=str.substring(str.length()-2,str.length());
  String b=str.substring(0,str.length()-2);
  
  return a+b;
}
public static void main(String[] args) {
	System.out.println(right2("Hello"));
	System.out.println(right2("java"));
	System.out.println(right2("Hi"));
}
}