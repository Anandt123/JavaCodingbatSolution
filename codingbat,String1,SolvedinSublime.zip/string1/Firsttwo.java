class Firsttwo
{
	public static String firstTwo(String str) {
  if(str.length()==0)
  {
    return "";
  }
  if(str.length()==1)
  {
    return str.substring(0);
  }
  return str.substring(0,2);
}
public static void main(String[] args) {
	System.out.println(firstTwo("hello"));
	System.out.println(firstTwo("abcdefg"));
	System.out.println(firstTwo("ab"));
}
}