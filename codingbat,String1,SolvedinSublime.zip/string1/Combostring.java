class Combostring
{
	public static String comboString(String a, String b) {
  if(a.length()>b.length())
  {
    return b+a+b;
  }
  if(b.length()>a.length())
  {
    return a+b+a;
  }
  return a+b;
}
public static void main(String[] args) {
	System.out.println(comboString("hello","hi"));
	System.out.println(comboString("hi","hello"));
}
}