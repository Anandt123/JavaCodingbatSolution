class Middlethree
{
	public static String middleThree(String str) {
  int a=str.length()/2;
  return str.substring(a-1,a+2);
}
public static void main(String[] args) {
	System.out.println(middleThree("candy"));
	System.out.println(middleThree("anand"));
}
}