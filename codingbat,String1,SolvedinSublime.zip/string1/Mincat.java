class Mincat
{
	public static String minCat(String a, String b) {
  if(a.length()==b.length())
  {
    return a+b;
  }
  if(a.length()>b.length())
  {
    int s=a.length()-b.length();
    return a.substring(s,a.length())+b;
  }
  if(a.length()<b.length())
  {
    int t=b.length()-a.length();
    return a+b.substring(t,b.length());
  }
  return "";
}
public static void main(String[] args) {
	System.out.println(minCat("Hello", "Hi"));
	System.out.println(minCat("Hello", "java"));
	System.out.println(minCat("java", "Hello"));
}
}