class Startword
{
	public static String startWord(String str, String word) {
  int lenstr=str.length();
  int lenword=word.length();
  if(lenstr==0)
  {
    return "";
  }
  if(lenstr<lenword)
  {
    return "";
  }
  if(word.length()==1)
  {
    return str.substring(0,1);
  }
  else if(str.substring(1,lenword).equals(word.substring(1,lenword)))
  {
    return str.substring(0,lenword);
  }
  else
  {
    return "";
  }
}
public static void main(String[] args) {
	System.out.println(startWord("hippo", "hi"));
	System.out.println(startWord("hippo", "xip"));
	System.out.println(startWord("hippo", "i"));
}
}