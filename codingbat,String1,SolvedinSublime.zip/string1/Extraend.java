class Extraend
{
	public static String extraEnd(String str) {
  
  String s=str.substring(str.length()-2,str.length());
    return s+s+s;
}
public static void main(String[] args) {
	System.out.println(extraEnd("Hello"));
	System.out.println(extraEnd("anand"));
}
}