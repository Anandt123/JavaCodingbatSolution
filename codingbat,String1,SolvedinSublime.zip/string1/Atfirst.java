class Atfirst
{
	public static String atFirst(String str) {
  if(str.length()==0)
  {
    return "@@";
  }
  if(str.length()==1)
  {
    return str+"@";
  }
  return str.substring(0,2);
}
public static void main(String[] args) {
	System.out.println(atFirst("hello"));
	System.out.println(atFirst("hi"));
	System.out.println(atFirst("h"));
}
}