class Firsthalf
{
	public static String firstHalf(String str) {
  String res=str.substring(0,str.length()/2);
  return res;
}
public static void main(String[] args) {
	System.out.println(firstHalf("WooHoo"));
	System.out.println(firstHalf("ANANDKUMAR"));
}
}